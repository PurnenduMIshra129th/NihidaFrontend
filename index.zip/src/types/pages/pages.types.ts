export interface IImageManagementPageProps {
  getDataEndPoint: string;
  updateDataEndPoint: string;
  deleteDataEndPoint: string;
}