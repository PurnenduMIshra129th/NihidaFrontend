export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;
export const STRIPE_KEY = import.meta.env.VITE_STRIPE_SECRET_KEY;
export const STRIPE_PUBLISHABLE_KEY = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY;

